

<?php

    $pkg_name = $_POST['pkg_name'];
    $pkg_price = $_POST['pkg_price'];
    $name= $_POST['name'];
    $email= $_POST['email'];
    $phone= $_POST['phone'];
    $address= $_POST['address'];
    $location= $_POST['location'];
    $guests= $_POST['guests'];
    $arrivals= $_POST['arrivals'];
    $leaving= $_POST['leaving'];
    $total_price = number_format($pkg_price.$guests);

    $conn = new mysqli('localhost','root','','travel_db');
    if($conn->connect_error){
        die('Connection failed :' .$connt->connect_error);
    }else{
        $stmt= $conn->prepare("insert into book_table(pkgname,pkgprice,name, email, phone, address, location, guests, arrivals, leaving) values(?,?,?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisssssiii",$pkg_name,$pkg_price,$name, $email, $phone, $address, $location, $guests, $arrivals, $leaving);
        $stmt->execute();
    } 
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <link href="paymentform.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="pmtstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        /* Styles for the dialog box */
        .dialog-box {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            height: 700px;
            width: 800px;
            transform: translate(-50%, -50%);
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
        .dialog-box a i{
            text-align: center;
            font-size: 2rem;
             }

                     /* Styles for the container */
        .container {
            display: none;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            padding: 20px;
            margin: 20px;
        }
        
        .order-message-container{
            text-transform: capitalize;
            font-weight: bold;

        }
       
        #h2,#h1{
            text-align: center;
        }
        .message-container .customer-details p{
            padding: 10px;
        }
        
    </style>
    <script>
        function openDialog() {
            // Get the dialog box element by its ID
            var dialogBox = document.getElementById('dialog-box');

            // Display the dialog box by setting its style property to "block"
            dialogBox.style.display = 'block';
        }

        function closeDialog() {
            // Get the dialog box element by its ID
            var dialogBox = document.getElementById('dialog-box');

            // Hide the dialog box by setting its style property to "none"
            dialogBox.style.display = 'none';
        }

        function checkFields() {
            // Get the input values
            var fnameValue = document.getElementById('fname').value;
            var lnameValue = document.getElementById('lname').value;
            var emailValue = document.getElementById('email').value;
            var cnoValue = document.getElementById('cno').value;
            var cvvValue = document.getElementById('cvv').value;
            var edValue = document.getElementById('ed').value;

            // Get the submit button element
            var submitButton = document.getElementById('submit-button');

            // Check if both name and email are filled
            if (fnameValue.trim() !== '' && lnameValue.trim() !== '' ) {
                submitButton.disabled = false; // Enable the button
            } else {
                submitButton.disabled = true; // Disable the button
            }
        }

        function toggleContainer() {
            // Get the container element by its ID
            var container = document.getElementById('my-container');

            // Toggle the visibility of the container
            if (container.style.display === 'none' || container.style.display === '') {
                container.style.display = 'block';
            } else {
                container.style.display = 'none';
            }
        }

    </script>
</head>

<body>
    <div class="wrapper">
        <h2>Payment Form</h2>
        <form method="post">
            <h4>Account</h4>
            <div class="input-group">
                <div class="input-box">
                    <input type="text" id="fname" placeholder="First Name" onkeyup="checkFields()" required class="name">
                    <i class="fa fa-user icon"></i>
                </div>
                <div class="input-box">
                    <input type="text" id="lname" placeholder="Last Name" onkeyup="checkFields()" required class="name">
                    <i class="fa fa-user icon"></i>
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <input type="email" id="email" placeholder="Email Adress" onkeyup="checkFields()" required class="name">
                    <i class="fa fa-envelope icon"></i>
                </div>
            </div>

            <div class="input-group">
                <div class="input-box">
                    <h4>Select Card</h4>
                    <input type="radio" name="pay" id="bc1" checked class="radio">
                    <label for="bc1"><span><i class="fa fa-cc-visa"></i>Debit</span></label>
                    <input type="radio" name="pay" id="bc2" class="radio">
                    <label for="bc2"><span><i class="fa fa-cc-mastercard"></i> Credit</span></label>
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <input type="number" id="cno" placeholder="Card Number" required class="name" onkeyup="checkFields()">
                    <i class="fa fa-credit-card icon"></i>
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <input type="text" id="cvv" maxlength="3"  placeholder="Card CVC" required class="name" onkeyup="checkFields()">
                    <i class="fa fa-user icon"></i>
                </div>
                <div class="input-box">
                    <input type="month" id="edate" required class="name" onkeyup="checkFields()">
                    
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <button type="submit" onclick="toggleContainer()" name="receipt" id="submit-button" >PAY &nbsp;<?php echo $total_price?> /-</button>
                </div>
            </div>
        </form>

    </div>

    <div id="dialog-box" class="dialog-box">
        <p><i class="fa-solid fa-circle-check fa-shake"></i>  GTavel Services</p>
        <p>
 
        <?php
  
    echo "
    <h1 id='h1' >GTravel Services</h1><hr><h2 id='h2'>Receipt</h2>
<div class='order-message-container'>
    <div class='message-container'>
       
       <div class='order-detail'>
          <span>".$pkg_name."</span>
          
       </div>
       <div class='customer-details'>
            <p><span>Tracsaction Id:</span></p>
          <p> your name : <span>".$name."</span> </p>
          <p> your number : <span>".$name."</span> </p>
          <p> your email : <span>".$email."</span> </p>
          <p> your paid amount : <span>".$name."</span> </p>
          <hr>
          <p>package price:<span>".$pkg_price."</span> </p>
          <p>no. of guests: </p>
          <p>payable amt.</p>
          <p>Convenience fee: </p>
          <p>total :</p>
          <h3>thank you for shopping!</h3>
      
    </div>
    ";
 
?>
       </p>
        <button class="btn" onclick="closeDialog()">Close</button><br>
        </div>
          <button><a href='home.php' class='btn'>Home</a></button>
       </div>
       <button id="printButton"> Print</button>
    </div>




    <!-- Container that is initially hidden -->
    <div id="my-container" class="container">
        <h2>Payment Successful....</h2>
        <p>Tracsaction ID: .</p>
        <button onclick="openDialog()">Download Reciept</button>
    </div>
    <script>
        // JavaScript for printing the receipt
        const printButton = document.getElementById('printButton');
        printButton.addEventListener('click', () => {
            window.print();
        });
    </script>
</body>
<script src="script.js"></script>

</html>
 
<!-- <?php
  if($stmt){
    echo "
    <div class='order-message-container'>
    <div class='message-container'>
       <h3>thank you for shopping!</h3>
       <div class='order-detail'>
          <span>".$name."</span>
          <span class='total'> total : $".$name."/-  </span>
       </div>
       <div class='customer-details'>
          <p> your name : <span>".$name."</span> </p>
          <p> your number : <span>".$name."</span> </p>
          <p> your email : <span>".$email."</span> </p>
          <p> your address : <span>".$name.", ".$name.", ".$name.", ".$name.", ".$name." - ".$name."</span> </p>
          <p> your payment mode : <span>".$name."</span> </p>
          <p>(*pay when product arrives*)</p>
       </div>
          <a href='products.php' class='btn'>continue shopping</a>
       </div>
    </div>
    ";
 }
?> -->
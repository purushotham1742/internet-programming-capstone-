

<?php

    // $source = $_POST['source'];
    // $dest = $_POST['destination'];
    // $name= $_POST['name'];
    // $email= $_POST['email'];
    // $phone= $_POST['phone'];

    // $b_detail= $_POST['bus_details'];
    // $date= $_POST['date'];

    $source = $_POST['source'];
    $destination = $_POST['destination'];
    $name= $_POST['name'];
    $email= $_POST['email'];
    $phone= $_POST['phone'];
    $date = $_POST['date'];
    $nextdate = $_POST['nextdate'];
    $ac_type = $_POST['ac_type'];
    $price = $_POST['price'];
    $arri_time = $_POST['arri_time'];
    $dept_time = $_POST['dep_time'];
    $bus_details = $_POST['bus_details'];



    $conn = new mysqli('localhost','root','','travel_db');
    if($conn->connect_error){
        die('Connection failed :' .$connt->connect_error);
    }else{
        $stmt= $conn->prepare("insert into bus_book(source,dest,name, email, phone,date, nextdate, ac_type, price, arri_time, dep_time,bus_details) values(?,?,?, ?, ?, ?,?, ?, ?, ?, ?,?)");
        $stmt->bind_param("ssssisssisss",$source,$destination,$name, $email, $phone, $date, $nextdate, $ac_type,$price, $arri_time, $dept_time, $bus_details);
        $stmt->execute();
       
    }
    ?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="pmtstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" >


    <style>
        /* Styles for the dialog box */
        .dialog-box {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            height: 700px;
            width: 800px;
            transform: translate(-50%, -50%);
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
        .dialog-box a i{
            text-align: center;
            font-size: 2rem;
             }

                     /* Styles for the container */
        .container {
            display: none;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            padding: 20px;
            margin: 20px;
        }
        
        .order-message-container{
            text-transform: capitalize;
            font-weight: bold;

        }
       
        #h2,#h1{
            text-align: center;
        }
        .message-container .customer-details p{
            padding: 10px;
        }
        .hidden {
            display: none;
        }
        
    </style>
    
</head>

<body>
    
    <div class="wrapper">
        <h2>Payment Form</h2>
    <form id="payment-form" action="busreceipt.php" method="post">
            <h4>Billing Details</h4>
            <div class="input-group">
                <div class="input-box">
                    <input type="text" id="fname" name="pfname" placeholder="Full Name" onkeyup="checkFields()" required class="name">
                    <i class="fa fa-user icon"></i>
                </div>
                <div class="input-box">
                    <input type="text" pattern="[0-9]{10}" id="lname" name="plname" placeholder="Enter 10 digit Mobile Number" onkeyup="checkFields()" required class="name">
                    <i class="fa fa-user icon"></i>
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <input type="email" id="email" name="pemail" placeholder="Email Adress" onkeyup="checkFields()" required class="name">
                    <i class="fa fa-envelope icon"></i>
                </div>
            </div>
            <div class="input-group">
                <span><input type="hidden" id="email" name="source" value="<?php echo $source?>" class="name" readonly></span>
                <span><input type="hidden" id="email" name="dest" value="<?php echo $destination?>" onkeyup="checkFields()"  class="name" readonly></span>
                <input type="hidden" value="<?php echo $bus_details;?>" name="bus_detail" >
                <input type="hidden" value="<?php echo $name;?>" name="name" >   
                <input type="hidden" value="<?php echo $phone;?>" name="phone" >   
                <input type="hidden" value="<?php echo $price;?>" name="price" >   
                <input type="hidden" value="<?php echo $email;?>" name="email" >  
                <input type="hidden" value="<?php echo $date;?>" name="date" >  
            </div>

     
            <div class="input-group">
                <div class="input-box">
                    <label for="payment-method">Payment Method:</label>
                        <select id="payment-method" name="payment-method">
                            <option value="cod">Cash on Delivery</option>
                            <option value="card">Credit/Debit Card</option>  
                            <option value="upi">UPI</option>
                        </select>
                </div>
            </div>

        <div id="card-info" class="hidden">
            <div class="input-group">
                <div class="input-box">
                    <!-- <input type="text" id="cno"  placeholder="Enter 16 digit Card Number" pattern="\d{4}-\d{4}-\d{4}-\d{4}" maxlength="19" class="name" onkeyup="checkFields()"> -->
                    <input type="text" id="card-number"  placeholder="Enter 16 digit Card Number" pattern="[0-9]{16}" maxlength="16" class="name" required onkeyup="checkFields()">
                    <i class="fa fa-credit-card icon"></i>
                </div>
            </div>

            <div class="input-group">
                <div class="input-box">
                    <input type="text" id="cvv" maxlength="3"   placeholder="Enter 3 digit CVC" pattern="[0-9]{3}" required class="name" onkeyup="checkFields()">
                    <i class="fa fa-user icon"></i>
                </div>
                <div class="input-box">
                    <input type="month" id="edate" required class="name" onkeyup="checkFields()">
                    
                </div>
            </div>
        </div>

            <div id="upi-info" class="hidden">
            <div class="input-group">
                <div class="input-box">
                    <input type="text" id="upi-id" name="upi-id" placeholder="UPI ID">
                </div>
            </div>
            </div>
            
            
            <div class="input-group">
                <div class="input-box">
                    <!-- <button type="submit" onclick="alert('Payment Successful...')" name="receipt" id="submit-button" >PAY &nbsp;<?php echo $total_price?> /-</button> -->
                    <button type="submit"  name="receipt" id="submit-button" >PAY &nbsp;<?php echo $price?> /-</button>
                </div>
            </div>
       
    </form>

    <script>
        const paymentMethodSelect = document.getElementById("payment-method");
        const cardInfo = document.getElementById("card-info");
        const upiInfo = document.getElementById("upi-info");

        paymentMethodSelect.addEventListener("change", function () {
            const selectedMethod = paymentMethodSelect.value;

            if (selectedMethod === "card") {
                cardInfo.classList.remove("hidden");
                upiInfo.classList.add("hidden");
            } else if (selectedMethod === "upi") {
                upiInfo.classList.remove("hidden");
                cardInfo.classList.add("hidden");
            } else {
                cardInfo.classList.add("hidden");
                upiInfo.classList.add("hidden");
            }
        });
    </script>

    </div>

</body>
<script src="script.js"></script>

</html>
 

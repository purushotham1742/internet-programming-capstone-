<?php 
$receiptno = $_GET['id'];

$conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
$sql = "UPDATE receipt_table SET status='requested' WHERE receiptno='$receiptno'";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");


mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cancel Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
        }

        p {
            color: #777;
        }

        .thank-you-message {
            background-color: lightskyblue;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }

        a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }
        .msg{
            color:black;
        }
        .no{
            color:red;
        }
        input{
            margin: 5px;
            padding: 5px;
        }
        p{
            color: black;
            margin: 10px;
            word-spacing: 4px;
            
        }
    </style>
</head>
<body>


<?php
// Assuming you have a database connection established

// Replace these variables with your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$database = "travel_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming $receiptno is already set elsewhere in your code
// Example, you might get it from a form or URL parameter

// Assuming $receiptno is already set elsewhere in your code
$receiptno = $_GET['id']; // Example, you might get it from a form or URL parameter

// Prepare SQL query to fetch data
$sql = "SELECT fname, total, ref_no FROM receipt_table WHERE receiptno = ?";

// Prepare and bind parameterized statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $receiptno);

// Execute the query
$stmt->execute();

// Bind the result variables
$stmt->bind_result($fname, $total, $refno);

// Fetch the results
if ($stmt->fetch()) {
    // Output the fetched data
  
} else {
    echo "No data found for receipt ID: $receiptno";
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>


    <div class="container">
        <h1>Request Received...</h1>
        <p>Dear <b><?php echo $fname;?></b>, request for ticket cancellation is received.</p>
        <p>we initiated the Refund of Amount<b> <?php echo $total;?>/-</b> <br><br>In your account with <b>Ref no.<?php echo $refno;?></b></p>
        <div class="thank-you-message">
            <p class="msg">For Receipt No: <span class="no"><?php echo $receiptno ?></span></p>
        </div>
        <a href="MyTrips.php"><input type="submit" value="Home"></a>
    </div>

</body>
</html>

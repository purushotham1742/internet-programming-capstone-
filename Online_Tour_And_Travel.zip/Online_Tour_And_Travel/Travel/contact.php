
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Contact Us</title>

    <meta name="author" content="Codeconvey" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>   
    <link rel="stylesheet" href="con_style.css">
    <!--Only for demo purpose - no need to add.-->
    <link rel="stylesheet" href="con_demo.css" />
	
    <style>
        body{
            background-image: url(images/bus_bg.jpeg);
        }
    </style>
</head>
<body>
		
<div class="ScriptTop">
    <div class="rt-container">
        <div class="col-rt-4" id="float-right">
 
            <!-- Ad Here -->
            
        </div>
        <div class="col-rt-2">
            <ul>
                <li><a href="login_form.php" title="Back to tutorial page">Back to Home</a></li>
            </ul>
        </div>
    </div>
</div>

<header class="ScriptHeader">

</header>

<section>
    <div class="rt-container">
          <div class="col-rt-12">
              <div class="Scriptcontent">
              
               <div>
            <div class="container">
                <div class="contact-parent">
                    <div class="contact-child child1">
                        <p>
                            <i class="fas fa-map-marker-alt"></i> Address <br />
                            <span> 201, MG Road Lane-I
                                <br />
                              Thane, IND
                            </span>
                        </p>

                        <p>
                            <i class="fas fa-phone-alt"></i> Let's Talk <br />
                            <span> 0787878787</span>
                        </p>

                        <p>
                            <i class=" far fa-envelope"></i> General Support <br />
                            <span>contact@example.com</span>
                        </p>
                    </div>

                    <div class="contact-child child2">
                        <div class="inside-contact">
                            <h2>Contact Us</h2>
                            <h3>
                               <span id="confirm">
                            </h3>
                            <div class="container">
       
       <form action="contact_form.php" method="post" class="contact-form">
        
           <input type="text" id="txt_name" placeholder="First Name" name="fname" required>
           <input type="text" id="txt_name2" placeholder="Last Name" name="lname" required>
           <input type="email" id="txt_email" placeholder="Email" name="email" required>
           <input type="text" id="txt_phone" placeholder="Mobile" name="number" required>
           <h2>Type Your Message Here...</h2>
           <textarea name="msg" id="txt_message" required></textarea>
           <input type="submit" onclick="contactMsg()" value="Send" id="button">
       </form>
   </div>
                            
    		</div>
		</div>
    </div>
    
</section>
    
    <!-- Analytics -->

	</body>
</html>
<?php

$conn = mysqli_connect('localhost', 'root', '', 'travel_db') or die('connection failed');
// @include 'config.php';

session_start();

if (!isset($_SESSION['user_name'])) {
    header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Packages</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../shopping cart/css/style.css">
    <!-- <link rel="stylesheet" href="../shopping cart/css/try.css"> -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

    <!-- font -->
    <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- custom css -->
    <link rel="stylesheet" href="mystyle.css">
    <link rel="stylesheet" href="#">
    <script src="script.js"></script>
    <style>
        .heading-pkg {
            font-size: 5rem;
            text-align: center;
            padding-bottom: 5rem;
            
        }

        .pkg-title {
            font-size: 3rem;
        }

        .pkg-icon {
            font-size: 2rem;
        }

        ul {
            position: relative;
            left: 50px;
            font-size: 2rem;

        }

        ul li {
            padding-bottom: 5px;
        }
        .pkgbtn{
            padding: 5px;
        }
        .pkgbtn:hover{
            cursor: pointer;
            color: purple;
            font-weight: bold;
        }
    </style>
    <link rel="stylesheet" href="pkg.css">
</head>

<body>



    <!-- header start -->
    <section class="header">
        <a href="login_form.php" id="out"><abbr title="Logout">⏪</abbr></a>
        <a class="logindetail logo">&nbsp;Hi,<?php echo $_SESSION['user_name'] ?>&nbsp;&nbsp;</a>
        <a href="#" class="logo"><span style="color:red;" class="gt">G</span>travel</a>
        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="about.php">about</a>
            <a href="Package.php">package</a>
            <a href="MyTrips.php">MyTrips</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars">☰</div>
    </section>
    <!-- header ends -->
    <div class="heading" style="background:url(images/banner1.jpg) no-repeat">
        <h1>package</h1>
    </div>
    <div style="display:inline-block; width:100%; height:50px; background-color:grey; font-size:25px;">
    Filter by package type - 
    <a href="pkgforeign.php"><button class="pkgbtn">Historical Sites</button> </a>
    <a href="pkgadv.php"><button class="pkgbtn">Adventure Destinations</button></a>
    <a href="pkgrel.php"><button class="pkgbtn">Religious Sites</button></a>
    <a href="pkgcruise.php"><button class="pkgbtn">Natural beauty</button></a>
    <a href="pkgcombo.php"><button class="pkgbtn">Special Combo</button></a>
    <a href="package.php"><button class="pkgbtn">All Tours</button></a>
    
    </div>







   





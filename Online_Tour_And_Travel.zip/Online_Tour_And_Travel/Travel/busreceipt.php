<?php
error_reporting(error_reporting() & ~E_WARNING);


// $name = $_POST['name'];
// $date = $_POST['date'];
// $email = $_POST['email'];
// $source = $_POST['source'];
// $dest = $_POST['dest'];
// $b_detail = $_POST['bus_detail'];

$source = $_POST['source'];
$destination = $_POST['dest'];
$name= $_POST['name'];
$email= $_POST['email'];
$phone= $_POST['phone'];
$date = $_POST['date'];
$nextdate = $_POST['nextdate'];
$ac_type = $_POST['ac_type'];
$price = $_POST['price'];
$arri_time = $_POST['arri_time'];
$dept_time = $_POST['dep_time'];
$bus_details = $_POST['bus_detail'];




// $conn = new mysqli('localhost', 'root', '', 'travel_db');
// if ($conn->connect_error) {
//     die('Connection failed :' . $connt->connect_error);
// } else {
//     $stmt = $conn->prepare("insert into pay_record(fname,lname,email,pkgname,pkgtotal,guests) values(?,?,?,?,?,?)");
//     $stmt->bind_param("ssssii", $fname, $number, $email,$pkgname,$total,$guests);
//     $stmt->execute();
    
    
// }

function generateRandomTransactionCode($length = 10) {
    $characters = '0123456789';
    $code = '';
    $maxIndex = strlen($characters) - 1;

    for ($i = 0; $i < $length; $i++) {
        $randIndex = mt_rand(0, $maxIndex);
        $code .= $characters[$randIndex];
    }

    return $code;
}

// Usage
$transactionCode = generateRandomTransactionCode(4); // Change the length as needed



function generateRandomSeat($length = 10) {
    $characters = '0123456789';
    $seat = '';
    $maxIndex = strlen($characters) - 1;

    for ($i = 0; $i < $length; $i++) {
        $randIndex = mt_rand(0, $maxIndex);
        $seat .= $characters[$randIndex];
    }

    return $seat;
}

// Usage
$SeatNo = generateRandomSeat(2); // Change the length as needed



function generateTransactionNumber($length) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $result = '';
    $charactersLength = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $result .= $characters[rand(0, $charactersLength - 1)];
    }
    return $result;
}

// Example usage: Generate a random transaction number of length 10
$refNo = generateTransactionNumber(10);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GT<?php echo $transactionCode ?></title>

    <style>
        .header h2{
    
    margin-left: 350px;
}
        .dialog-box {
            width: 800px;
            height: 500px;
            margin: 0 auto;
            padding-left: 20px;
            padding-right: 20px;
            border: 1px solid black;
        }
        /* .button-container {
            display: flex;
            align-items: center;
        } */
        .gt1{
            display: inline;
            padding-left: 230px;
            
        }
        h3{
            text-align: center;
        }
        

.btn1{
    display: inline-block;
    background: rgb(238, 128, 26);
    margin-top: 0.5rem;
    color:rgb(255, 255, 255);
    align-items: center;
    font-size: 1.2rem;
    padding:0.5rem 2rem;
    cursor: pointer;
    position: relative;
    left: 1200px;
    top:20px;
    
}
.btn1:hover{
    background: rgb(238, 142, 86);
}

.head{
    text-align: center;
    
}
p{
    font-weight: bold;
    font-size: 1.2rem;
}
span{
    color:red;
}
.header{
    position: static;
    top:0; left:0; right:0;
    z-index: 1000;
    background-color: orange;
    display: flex;
    padding-top: 0.5rem;
    padding-bottom: 1rem;
    box-shadow: black;
    padding-left: 380px;
    justify-content: space-between;
}
.btn{
    display: flex;
    align-items:center;
    justify-content: space-between;
    flex-wrap: wrap;
}
nav{
    display: flex;
    align-items:center;
    justify-content: space-between;
    flex-wrap: wrap;
}
.head{
    position: static;
    top:0; left:0; right:0;
    z-index: 1000;
    background-color: orange;
    display: flex;
    padding-top: 0rem;
    padding-bottom: -1rem;
    box-shadow: black;
    padding-left: 95px;
    justify-content: space-between;
}
.nav{
    text-align: center;
}
.btn2{
    position: relative;
    left: 1200px;
    top: -80px;
    
}
.from{
    margin-top: 20px;
}
    </style>
</head>

<body>
<?php




        echo "
        <nav class='header'><h2>Gtravel Reciept Page</h2></nav><br>
    <div id='dialog-box' class='dialog-box'>
        <nav class='head'><h3 class='head' >GTravel &nbsp; Receipt No: <span>GT".$transactionCode."</span></p></h3><hr></nav>
        <hr/>
     <div class='order-message-container'>
    <div class='message-container'>
       <div>
        <nav>
           <p> Bus: <span>" . $bus_details . "</span></p><br>
           <p> Name : <span>" . $name . "</span> </p>&nbsp;&nbsp;
          <p> Number : <span>" . $phone . "</span> </p><br>
          <p> Email : <span>" . $email . "</span> </p>&nbsp;&nbsp;
          <p> Journey Date : <span>" . $date . "</span> </p>&nbsp;&nbsp;
          <p class='from'>From:<span >".$source."</span> </p><br>
          <p class='from'><span >"."&nbsp;&nbsp;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"."</span> </p><br>
          <p>To:<span class='to'>".$destination."</span> </p><br>
          <p>Convenience fee: 0/- </p><br><br>
          <p>Fare:<span>" .$price. "</span> </p>
          <p>Seat No:<span>" .$SeatNo. "</span> </p>
          <p>Ref No:<span>" .$refNo. "</span> </p>


        </nav>
       
    </div>    
</div><br>
<div class='gt1' >
    <img src='images/travel.jpg' alt=''>
   </div><br>
</div>";

        error_reporting(error_reporting() | E_WARNING);

        ?>
        </p>
    </div>
<br>
<div class='btn'>
<button class='btn1' id='printButton'><i class='fa-solid fa-print'></i> Print</button> 
</div>

       
    <script>
        // JavaScript for printing the receipt
        const printButton = document.getElementById('printButton');
        printButton.addEventListener('click', () => {
            window.print();
        });
    </script>

<form action="thankyou.php" method="post">
<span><input type="hidden" id="email" name="receiptno" value="GT<?php echo $transactionCode?>"  class="name"></span>   
<span><input type="hidden" id="email" name="pkgname" value="<?php echo $bus_details?>"  class="name"></span>   
<span><input type="hidden" id="email" name="fname" value="<?php echo $name?>"  class="name"></span>   
<span><input type="hidden" id="email" name="email" value="<?php echo $source.' to '.$destination?>"  class="name"></span>   
<span><input type="hidden" id="email" name="total" value="<?php echo $price?>"  class="name"></span>  
<span><input type="hidden" id="email" name="seat" value="<?php echo $SeatNo?>"  class="name"></span>  
<span><input type="hidden" id="email" name="refno" value="<?php echo $refNo?>"  class="name"></span>  
<span><input type="hidden" id="email" name="status" value="booked"  class="name"></span>  
 
<a href='home.php'><input type="submit" class='btn1 btn2' value="Home"></a>


</form>


</body>

</html>
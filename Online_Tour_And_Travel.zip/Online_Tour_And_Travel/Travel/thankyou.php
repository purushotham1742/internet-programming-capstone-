<?php 

$fname= $_POST['fname'];
$pkgname= $_POST['pkgname'];
$email= $_POST['email'];
$total= $_POST['total'];
$receiptno= $_POST['receiptno'];
$status= $_POST['status'];
$seat= $_POST['seat'];
$ref= $_POST['refno'];

$conn = new mysqli('localhost','root','','travel_db');
if($conn->connect_error){
    die('Connection failed :' .$connect_error);
}else{
    $stmt= $conn->prepare("insert into receipt_table(fname, pkgname, email, total, receiptno,status,seat_no,ref_no) values(?, ?, ?, ?, ?,?,?,?)");
    $stmt->bind_param("sssissss", $fname, $pkgname, $email, $total, $receiptno,$status,$seat,$ref);
    $stmt->execute();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Thank You for Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
        }

        p {
            color: #777;
        }

        .thank-you-message {
            background-color: lightskyblue;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }

        a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }
        .msg{
            color:black;
        }
        .no{
            color:red;
        }
        input{
            margin: 5px;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank You for Booking</h1>
        <p>Your reservation is confirmed. We look forward to serving you!</p>
        <div class="thank-you-message">
            <p class="msg">Your Receipt No: <span class="no"><?php echo $receiptno ?></span></p>
        </div>

         
        <a href="home.php"><input type="submit" value="Home"></a>
    </div>
</body>
</html>

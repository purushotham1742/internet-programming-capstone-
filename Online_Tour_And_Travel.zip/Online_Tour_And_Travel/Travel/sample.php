
<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root"; // Your MySQL username
    $password = ""; // Your MySQL password
    $database = "travel_db"; // Your MySQL database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetching values from form
    $source = $_POST['from'];
    $destination = $_POST['to'];
    $date=$_POST['date'];
    $nextDate = date('d/m/y', strtotime($date . ' +1 day'));
    $org_date = date('d/m/y', strtotime($date));
  

    // Construct SQL query
    $sql = "SELECT * FROM buses WHERE source = '$source' AND destination = '$destination'";

    // Execute SQL query
    $result = $conn->query($sql);

    // Check if there are results
    if ($result->num_rows > 0) {
        // Output data of each row
        echo "<h3 class='bus_head'>Available Buses</h3>";
        
              // Output data of each row
              while($row = $result->fetch_assoc()) { ?>
                <form action="book.php" method="POST">
                <div class="c_bus">
                <div class="bus-details">
                <div class="bus-number"><?php echo $row["busno"].'&nbsp;&nbsp;'.$row["bus_name"];?> </div>
                <span class="seat"><?php  echo $row["ac_type"]?>&nbsp;|&nbsp;<?php $row["seat"]?>&nbsp;Seats  &nbsp;</span>
                <span class="arri-dep arri "><?php echo $row["arri_time"] ?>&nbsp;|&nbsp;<?php $row["source"]?></span>
                <span class="date"><?php echo $org_date ?> </span>
                <span class="nxt-date"><?php echo $nextDate ?> </span>
                <span class="arri-dep dep "><?php echo $row["dep_time"]?>&nbsp;|&nbsp; <?php $row["destination"] ?></span>
                <span><p class="price">&#8377;<?php echo $row["price"]; ?> </p><span>
                <input type="hidden" name="source" value="<?php echo $source; ?>">
                <input type="hidden" name="destination" value=" <?php echo $destination; ?>">
                <input type="hidden" name="date" value="<?php echo $org_date; ?>" >
              
                <!-- <button type="submit" class="booking-button">Book Now</button> -->
                <div class="booking-button"><a href="book.php?book=<?php echo $row["sr"]; ?>" > Book Now</a></div>

                </div>
                </div>
                </form>
          <?php  }?>
        <?php } else {
            echo "<p>No buses found for the provided source and destination.</p>";
        }
      

    // Close database connection
    $conn->close();
}
?>

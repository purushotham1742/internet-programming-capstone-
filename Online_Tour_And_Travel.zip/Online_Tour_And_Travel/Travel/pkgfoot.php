
<footer>
        <section class="footer">

            <div class="box-container">

                <div class="box">
                    <h3>Quick links</h3>
                    <a href="home.php"><i class="fas fa-angle-right"></i> home</a>
                    <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
                    <a href="Package.php"><i class="fas fa-angle-right"></i>package</a>
                    <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
                </div>

                <div class="box">
                    <h3>Extra links</h3>
                    <a href="#"><i class="fas fa-angle-right"></i>Ask questions</a>
                    <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                    <a href="#"><i class="fas fa-angle-right"></i>Privacy Policy</a>
                    <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
                </div>

                <div class="box">
                    <h3>Contact info</h3>
                    <a href="#"><i class="fas fa-phone"></i>+91 123-4567-890</a>
                    <a href="#"><i class="fas fa-phone"></i>+91 111-4567-890</a>
                    <a href="#"><i class="fas fa-envelope"></i>mymail@gmail.com</a>
                    <a href="#"><i class="fas fa-map"></i>Mumbai, India - 400104</a>
                </div>

                <div class="box">
                    <h3>follow us</h3>
                    <a href="#"><i class="fab fa-facebook-f"></i> facebook</a>
                    <a href="#"><i class="fab fa-twitter"></i> twitter</a>
                    <a href="#"><i class="fab fa-instagram"></i> instagram</a>
                    <a href="#"><i class="fab fa-linkedin"></i> linkedin</a>
                </div>
                <!-- <div class="credit" style="position:relative; text-align:center; width:500px;">created by <span>Gupta Developers</span> | all right reserved!</div> -->

            </div>

        </section>
    </footer>

    <!-- custom js file link  -->
    <script src="js/script.js"></script>

</body>

</html>
<?php

@include 'config.php';

session_start();

if (isset($_POST['submit'])) {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = md5($_POST['password']);

    $select = " SELECT * FROM user_data WHERE email = '$email' && password = '$pass' ";

    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {

        $row = mysqli_fetch_array($result);

        if ($row['user_type'] == 'admin') {

            $_SESSION['admin_name'] = $row['name'];
            header('location:http://localhost/myphp/MyProject/Online_Tour_And_Travel/Online_Tour_And_Travel/crud_html/dashboard.php');
        } elseif ($row['user_type'] == 'user') {

            $_SESSION['user_name'] = $row['name'];
            header('location:home.php');
        }
    } else {
        $error[] = 'incorrect email or password!';
    }
};
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gtravel : login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="mystyle.css">
    <script src="/script.js"></script>


    <style>
        body {
            background: url("images/test.jpg");  
           background-repeat:no-repeat;
    
        }

        .autoWritter {
            font-family: arial;
            display: table;
            /* margin: 50px auto; */
        }

        .autoWrite-text {

            color: #ffffff;
            text-shadow: 2px 2px black;
            display: inline-block;
            overflow: hidden;
            position: relative;
            top: -150px;
            left: -30px;
            white-space: nowrap;
            letter-spacing: 2px;
            /*-- Call text and cursor animation --*/
            animation: write 3s steps(40, end), cursor .7s step-end infinite;
            font-size: 70px;
            border-right: 4px solid;
        }

        /*-- Write text as Animated --*/
        @keyframes write {
            from {
                width: 0%
            }

            to {
                width: 100%
            }
        }

        /*-- Animated blink cursor CSS--*/
        @keyframes cursor {

            from,
            to {
                border-color: transparent;
            }

            50% {
                border-color: #ff9800;
            }
        }



        .content h3 {

            font-size: 6vw;
            color: var(--white);
            text-transform: uppercase;
            /* line-height: 1; */
            text-align: center;
            text-shadow: 2px 2px red;
            padding: 1rem 0;
            animation: fadeIn .5s linear backwards .4s;
        }

        .formbox {
            position: relative;
            top: -120px;
            border: 2px solid red;
            border-radius: 50px 20px;
        }

        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        .container {
            min-height: 100vh;
            background: #08071d;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url("bus_bg.jpeg") no-repeat center center/cover;
        }

        .container form {
            width: 670px;
            height: 400px;
            display: flex;
            justify-content: center;
            box-shadow: 20px 20px 50px rgba(0, 0, 0, 0.5);
            border-radius: 15px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            flex-wrap: wrap;
        }

        .container form h1 {
            color: #333;
            font-weight: 500;
            margin-top: 20px;
            width: 500px;
            text-align: center;
        }

        .container form input {
            width: 290px;
            height: 40px;
            padding-left: 10px;
            outline: none;
            border: 1px solid black;
            font-size: 15px;
            margin-bottom: 10px;
            background: none;
            border-bottom: 2px solid #fff;
        }

        .container form input::placeholder {
            color: #333;
        }

        .container form #lastName,
        .container form #mobile {
            margin-left: 20px;
        }

        .container form h4 {
            color: #333;
            font-weight: 300;
            width: 600px;
            margin-top: 20px;
        }

        .container form textarea {
            background: none;
            border: 1px solid black;
            border-bottom: 2px solid #fff;
            color: #333;
            font-weight: 300;
            font-size: 15px;
            padding: 10px;
            outline: none;
            min-width: 600px;
            max-width: 600px;
            min-height: 80px;
            max-height: 80px;
        }
        .gt{
            color: red;
        }

        textarea::-webkit-scrollbar {
            width: 1em;
        }

        textarea::-webkit-scrollbar-thumb {
            background-color: rgba(194, 194, 194, 0.713);
        }

        .container form #button {
            border: none;
            background: red;
            border-radius: 5px;
            margin-top: 20px;
            font-weight: 600;
            font-size: 20px;
            color: #333;
            width: 100px;
            padding: 0;
            margin-right: 500px;
            margin-bottom: 30px;
            transition: 0.3s;
        }

        .container form #button:hover {
            opacity: 0.5;
        }

        /* client review*/
        .review-container {
            position: relative;
            left: 250px;
            bottom: 20px;

            width: 800px;
            min-width: 350px;
            min-height: 250px;
            padding-bottom: 40px;
            overflow: hidden;
        }

        .review-wrap {
            width: 300%;
            /* 300% 'caz we have 3 cards */
            min-height: 100%;
            display: flex;
            justify-content: space-between;
            transition: 1s;
        }

        .card {
            width: 800px;
            min-height: 100%;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            margin: 0 10px;
        }

        .card-thumb {
            width: 70%;
            height: 250px;
            overflow: hidden;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
            position: relative;
        }

        .client-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .client-name {
            position: absolute;
            bottom: 10px;
            right: 10px;
            border-top-left-radius: 50px;
            border-bottom-left-radius: 50px;
            padding: 5px 20px;
            background: #fff;
            text-transform: capitalize;
            font-size: 14px;
        }

        .card-body {
            width: 120%;
            min-height: 100%;
            height: auto;
            margin-left: 20px;
            position: relative;
            padding-bottom: 50px;
        }

        .review {
            font-size: 20px;
            line-height: 30px;
            margin-top: 30px;
        }

        .rating {
            position: absolute;
            bottom: 10px;
            left: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .star {
            font-size: 20px;
        }

        .indicators {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
        }

        .indicators button {
            background: none;
            border: none;
            outline: none;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            border: 2px solid #333;
            cursor: pointer;
            margin-left: 5px;
            transition: .5s;
        }

        button.active {
            width: 40px;
            border-radius: 50px;
            background: #333;
        }


        .btn {
            display: inline-block;
            background: var(--black);
            margin-top: 1rem;
            color: var(--white);
            font-size: 1.7rem;
            padding: 1rem 3rem;
            cursor: pointer;
        }

        .btn:hover {
            background: var(--main-color);
        }

        .myht {
            text-align: center;
            margin-bottom: 3rem;
            font-size: 6rem;
            text-transform: uppercase;
            color: var(--black);
        }




    .mypkg .my-pkg-cont {
            display: grid;
    grid-template-columns: repeat(auto-fit, minmax(30rem, 1fr));
    gap: 2rem;
  
}



        .mypkg .my-pkg-cont .pkg-box {
            border: var(--border);
            box-shadow: var(--box-shadow);
            background: var(--white);

        }


        .mypkg .my-pkg-cont .pkg-box:hover .image img {
            transform: scale(1.1);
        }

        .mypkg .my-pkg-cont .pkg-box .image {
            height: 25rem;
            overflow: hidden;
        }

        .mypkg .my-pkg-cont .pkg-box .image img {
            height: 100%;
            width: 100%;
            object-fit: cover;
            transition: .2s linear;
        }

        .mypkg .my-pkg-cont .pkg-box .content {
            padding: 2rem;
            text-align: center;
        }



        .mypkg .my-pkg-cont .pkg-box .content {
            padding: 2rem;
        }

        .mypkg .my-pkg-cont .pkg-box .content h3 {
            font-size: 2.5rem;
            color: var(--black);
        }

        .mypkg .my-pkg-cont .pkg-box .content p {
            font-size: 1.5rem;
            color: var(--light-black);
            line-height: 2;
            padding: 1rem 0;
        }

        .mypkg .load-more {
            text-align: center;
            margin-top: 2rem;
        }
        ul{margin: 15px;
            padding-right: 50px;
            font-size: 20px;
            font-weight: bold;
        }
        .i-logo{
            font-size: 70px;
        }
        .form-container form{
            background-color:#ADD8E6;
        }
    </style>
    <!-- <link rel="stylesheet" href="pkg.css"> -->
</head>

<body>

    <section class="header">
        <a href="#" class="logo"><span class="gt">G</span>travel</a>
        <nav class="navbar">
            <a href="#">home</a>
            <a href="contact.php">Contact Us</a>
            <a href="#" onclick="alert('Login First');">aboutUs</a>
            <a href="#" onclick="alert('Login First');">packages</a>
            
            <a href="login_form.php">Login</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars">☰</div>
    </section>


    <div class="content">
        <h3>discover the new place</h3>
    </div>

    <div class="form-container">
        <div class="autoWritter">
            <h2 class="autoWrite-text">Welcome To <span class="gt">Gupta Tour</span><br /> and Travel Services</h2>
        </div>
        <form class="formbox" method="post">
            <h3>login now</h3>
            <?php
            if (isset($error)) {
                foreach ($error as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                };
            };
            ?>
            <input type="email" name="email" required placeholder="enter your email">
            <input type="password" name="password" required placeholder="enter your password">
            <input type="submit" name="submit" value="login now" class="form-btn">
            <p>don't have an account? <a href="register_form.php">register now</a></p>
        </form>

    </div>
    

     <!-- service section starts -->
     <section class="services">
        <h1 class="heading-title">our services</h1>

        <div class="box-container">
            <a href="package.php">
                <div class="box">
                <i class="fa-solid fa-couch i-logo"></i>
                    <h3>Comfort</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                <i class="fa-regular fa-compass i-logo"></i>
                     <h3>Tour guide</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                <i class="fa-regular fa-clock i-logo"></i>                 
                   <h3>27x7 Support</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                    <img src="images\icon4.jpeg" alt="cf">
                    <h3>Ac/Non-Ac</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                    <img src="images\icon5.png" alt="or">
                    <h3>Delux</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                    <img src="images\icon6.png" alt="camp">
                    <h3>camping</h3>
                </div>
            </a>
        </div>
    </section>

    <!-- service section ends -->

    <section class="mypkg">
        <h1 class="myht">top destination</h1>
        <div class="my-pkg-cont">

            <div class="pkg-box">
                <div class="image">
                    <img src="images/tajmahal.jpg" alt="">
                </div>
                <div class="content">
                    <h1 style="font-size:30px;"><u>Beauty Of Taj</u></h1>
                  <ul>
                    <li>Great Experience</li>
                    <li>5 Nights/4 Days</li>
                    <li>Hotel/Meal/Cab</li>
                  </ul>
                  <span>starts from</span> <span style="color:black; font-size:30px; font-weight:bold;">&#8377;7999/- </span>
                  <a href="login_form.php" class="btn" onclick="alert('Login Please')">Book Now</a>

                </div>
            </div>
            <div class="pkg-box">
                <div class="image">
                    <img src="images/img3.jpg" alt="">
                </div>
                <div class="content">
                <h1 style="font-size:30px;"><u>Golden Tample</u></h1>
                  <ul>
                    <li>Complete Amritsar tour</li>
                    <li>3 Nights/2 Days</li>
                    <li>Hotel/Meal/Cab</li>
                  </ul>
                  <span>starts from</span><span style="color:black; font-size:30px; font-weight:bold;">&#8377;8999/- </span>
                    <a href="login_form.php" class="btn" onclick="alert('Login Please')">Book Now</a>
                </div>
            </div>
            <div class="pkg-box">
                <div class="image">
                    <img src="images/gate.jpg" alt="">
                </div>
                <div class="content">
                <h1 style="font-size:30px;"><u>Delhi Tour</u></h1>
                  <ul>
                    <li>Complete Guide</li>
                    <li>5 Nights/6 Days</li>
                    <li>Hotel/Meal/Cab</li>
                  </ul>
                  <span>starts from</span><span style="color:black; font-size:30px; font-weight:bold;">&#8377;9,999/- </span>
                    <a href="login_form.php" class="btn" onclick="alert('Login Please')">Book Now</a>
                </div>
            </div>

        </div>
        <div class="load-more"><span class="btn"><a href="login_form.php" onclick="alert('Login Please')">load more</a></span></div>
    </section>


    <!-- contact us -->
    <br><br><br>
    <h1 class="myht">Touch With Us....</h1>
    <div class="container">
       
        <form action="contact_form.php" method="post" class="contact-form">
            <h1>Contact Us Form</h1>
            <input type="text" id="firstName" placeholder="First Name" name="fname" required>
            <input type="text" id="lastName" placeholder="Last Name" name="lname" required>
            <input type="email" id="email" placeholder="Email" name="email" required>
            <input type="text" id="mobile" placeholder="Mobile" name="number" required>
            <h2>Type Your Message Here...</h2>
            <textarea name="msg" required></textarea>
            <input type="submit" onclick="contactMsg()" value="Send" id="button">
        </form>
    </div>

    <!-- contact us -->

    <!-- client reviews -->
    <div class="h">
        <h1 class="myht">OUR CLIENTS</h1>
    </div>
    <div class="review-container">

        <div class="review-wrap">
            <div class="card">
                <div class="card-thumb">
                    <img src="images/rev2.png" class="client-img" alt="">
                    <span class="client-name">Amit Sharma</span>
                </div>
                <div class="card-body">
                    <p class="review">"Amazing tour experience! The sights were breathtaking, and our guide was incredibly knowledgeable. A truly unforgettable adventure. Highly recommended!"</p>
                    <div class="rating">
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-thumb">
                    <img src="images/revgirl.png" class="client-img" alt="">
                    <span class="client-name">Adelina</span>
                </div>
                <div class="card-body">
                    <p class="review">"Absolutely amazing tour experience! The sights were breathtaking, the guides were knowledgeable, and the memories will last a lifetime. Can't wait to book another adventure with you!"</p>
                    <div class="rating">
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-thumb">
                    <img src="images/rev1.png" class="client-img" alt="">
                    <span class="client-name">Sumit</span>
                </div>
                <div class="card-body">
                    <p class="review">Realy Great Experience, Must Try there Affordable Packages</p>
                    <div class="rating">
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                        <i class="star">⭐</i>
                    </div>
                </div>
            </div>

        </div>
        <div class="indicators">
            <button class="active"></button>
            <button></button>
            <button></button>
        </div>
    </div>


    <script>
        const wrapper = document.querySelector('.review-wrap');
        const indicators = [...document.querySelectorAll('.indicators button')];

        let currentTestimonial = 0; // Default 0

        indicators.forEach((item, i) => {
            item.addEventListener('click', () => {
                indicators[currentTestimonial].classList.remove('active');
                wrapper.style.marginLeft = `-${100 * i}%`;
                item.classList.add('active');
                currentTestimonial = i;
            })
        })
    </script>


    <!-- client reviews -->


    <!-- footer -->

    <footer>
        <section class="footer">

            <div class="box-container">

                <div class="box">
                    <h3>Quick links</h3>
                    <a href="home.php"><i class="fas fa-angle-right"></i> home</a>
                    <a href="abouts.php"><i class="fas fa-angle-right"></i>about</a>
                    <a href="login_form.php"><i class="fas fa-angle-right"></i>package</a>
                    <a href="login_form.php"><i class="fas fa-angle-right"></i>book</a>
                </div>

                <div class="box">
                    <h3>Extra links</h3>
                    <a href="#"><i class="fas fa-angle-right"></i>Ask questions</a>
                    <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                    <a href="#"><i class="fas fa-angle-right"></i>Privacy Policy</a>
                    <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
                </div>

                <div class="box">
                    <h3>Contact info</h3>
                    <a href="#"><i class="fas fa-phone"></i>+91 123-4567-890</a>
                    <a href="#"><i class="fas fa-phone"></i>+91 111-4567-890</a>
                    <a href="#"><i class="fas fa-envelope"></i>mymail@gmail.com</a>
                    <a href="#"><i class="fas fa-map"></i>Mumbai, India - 400104</a>
                </div>

                <div class="box">
                    <h3>follow us</h3>
                    <a href="#"><i class="fab fa-facebook-f"></i> facebook</a>
                    <a href="#"><i class="fab fa-twitter"></i> twitter</a>
                    <a href="#"><i class="fab fa-instagram"></i> instagram</a>
                    <a href="#"><i class="fab fa-linkedin"></i> linkedin</a>
                </div>

            </div>

            <div class="credit">created by <span>Gupta Developers</span> | all right reserved!</div>

        </section>
    </footer>

    <!-- footer -->
</body>

</html>
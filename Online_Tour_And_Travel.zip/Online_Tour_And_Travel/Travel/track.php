<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        h1 {
            text-align: center;
        }
        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
 
<div class="wrapper">

<table class="tbl-full">
            <tr>
        
                <th>Package Name</th>
                <th>Biller Name</th>
                <th>Email</th>
                <th>Receipt No</th>
                <th>Total Amt.</th>
                <th>Status</th>
                <th>Action</th>
               
            </tr>

    <div class="product-main">
        <?php
        $conn = mysqli_connect('localhost','root','','travel_db') or die('connection failed');
              //get the search keyword
               $search = mysqli_real_escape_string($conn, $_POST['search']);
        ?>
    
        <h2 class="title text-center success "> Searched By - <label style='color: red;'> <?php echo $search; ?></h2>

        <div class="product-grid">

        <?php

             //Get the search keyword
             $search = $_POST['search'];

             //Sql query to get product based on search keyboard
             $sql = "SELECT * FROM receipt_table WHERE receiptno='$search'";

             //Execute the query
             $res = mysqli_query($conn , $sql);

             //Count rows
             $count = mysqli_num_rows($res);

             //check whether product available or not
             if($count>0)
             {
               //product available
               while($row=mysqli_fetch_assoc($res))
               {
                 //Get the details
                
                 $fname = $row['fname'];
                 $email = $row['email'];
                 $pkgname = $row['pkgname'];
                 $price = $row['total'];
                 $receiptno = $row['receiptno'];
                 $status = $row['status'];
               

                 ?>

                  <tr>
                          <td><?php echo $pkgname; ?> </td>
                           <td><?php echo $fname; ?> </td>
                           <td><?php echo $email; ?> </td>
                           <td><?php echo $receiptno; ?> </td>

                           <td><?php echo $price; ?> </td>
                           <td><?php echo $status; ?> </td>
                           <td>
                    <a href='cancelpkg.php?id=<?php echo $row['receiptno'] ?>'>cancel</a>
                </td>
                  </tr>      


</div>
</div>

                 <?php
               }
             }
             else
             {
               //Product Not Available
               echo "<div class='error'> No Booking Record Found....</div>";
             }
         
               ?>
        </div>
      </div>
            </div>
</body>
</html>





<br/><br/>
    <h2>Edit Record</h2>
    <form class="post-form" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
        <div class="form-group">
            <label>S No.</label>
            <input type="text" name="sno" />
        </div>
        <input class="submit" type="submit" name="showbtn" value="Show" />
    </form>

    <?php
    if(isset($_POST['showbtn'])){

    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sno_id=$_POST['sno'];
    $sql = "SELECT * FROM receipt_table WHERE receiptno = '$sno_id'";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");
    
    if(mysqli_num_rows($result)>0){

        while($row=mysqli_fetch_assoc($result)){
    
    ?>

    <form class="post-form" action="updatedata.php" method="post">
        <div class="form-group">
            <label for="">Name</label>
            <input type="hidden" name="sno"  value="<?php echo $row['sno'];?>" />
            <input type="text" name="name" value="<?php echo $row['fname'];?>" />
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $row['email'];?>" />
        </div>
        
    <input class="submit" type="submit" value="Update"  />
    </form>
<?php
        }
    }
}
?>

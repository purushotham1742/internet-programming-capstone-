<?php include 'header.php'; ?>


<head>
<style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  
  }
  
  .bus_head{
    font-size: 20px;
    width: 50%;
    color: black;
    text-align: center;
    background-color: yellow;
    margin-left: 450px;
  }
  .cont {
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    background-color: #f5f5f5;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
  
  h1 {
    text-align: center;
  }
  
  .form-group {
    margin-bottom: 20px;
  }
  
  label {
    display: block;
    margin-bottom: 5px;
  }
  
  input[type="text"],
  input[type="date"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
  }
  
  button {
    display: block;
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }

  .c_bus {
    width: 1200px;
    margin: 20px auto;
    padding: 0 20px;
    box-shadow: 2px;
  }

  .bus-details {
    background-color: #fff;
    border-radius: 18px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 20px;
    background-color: #fff;
       transition: box-shadow 0.3s ease; /* Added transition for shadow */
  }

  .bus-details:hover {
  border: 2px solid #007bff; /* Change border color on hover */
  background-color: #c3c3c3;
  }
  .bus-number {
    font-size: 15px;
    font-weight:600;
    color: #333;
    margin-bottom: 10px;
  }

  .arri-dep{
    font-size: 24px;
    font-weight: bold;
    color: #333;
    margin-bottom: 10px;
    text-transform: uppercase;
    color: red;

  }
  .arri{
    margin-left: 50px;
  }

  .dep{
    margin-left: 250px;
  }
  .departure-time {
    color: #666;
    margin-bottom: 15px;
  }

   .booking-button {
    display: inline;
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    height: 40px;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
  }
  .date{
    font-size: 15px;
    position: relative;
    top:20px;
    left: -120px;
    color: red;
  }
  .seat{
  position: relative;
  left: 500px;
  top: -10px;
  font-size: 20px;
  }
  .nxt-date{
    font-size: 15px;
    position: relative;
    top:25px;
    left: 400px;
    color: red;
    margin: 5px;
  }
  .price{
    margin-left: 1020px;
    margin-top:-10px;
    font-size: 18px;

  }

  .booking-button:hover {
    background-color: #0056b3;
    
  }
  .noresult{
    text-align: center;
    background: red;
    width: 40%;
    margin-top: -470px;
    margin-left: 500px;
    font-size: 20px;
    font-weight:100%;
  }
  
</style>
</head>
<body style="background:url(images/test.jpg)">
<div class="cont">
    <h1>Bus Search</h1>
    <form action="" method="POST"> <!-- Added method="POST" to the form -->
        <div class="form-group">
            <label for="from">From:</label>
            <input type="text" id="from" name="from" placeholder="Enter starting point" required>
        </div>
        <div class="form-group">
            <label for="to">To:</label>
            <input type="text" id="to" name="to" placeholder="Enter destination" required>
        </div>
        <div class="form-group">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>
        </div>
        <button type="submit" id="bookBtn">Search</button> <!-- Added id="bookBtn" -->
    </form>
</div>
<script>
    document.getElementById('bookBtn').addEventListener('click', function() {
        document.getElementById('dialog').style.display = 'block';
    });

    document.querySelector('.close').addEventListener('click', function() {
        document.getElementById('dialog').style.display = 'none';
    });

</script>


<script>
                // Get the current date in YYYY-MM-DD format
                const today = new Date();
                const year = today.getFullYear();
                let month = today.getMonth() + 1;
                let day = today.getDate();

                if (month < 10) {
                    month = `0${month}`;
                }

                if (day < 10) {
                    day = `0${day}`;
                }

                const currentDate = `${year}-${month}-${day}`;

                // Set the minimum date for the input element
                document.getElementById("date").min = currentDate;
            </script>

<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root"; // Your MySQL username
    $password = ""; // Your MySQL password
    $database = "travel_db"; // Your MySQL database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetching values from form
    $source = $_POST['from'];
    $destination = $_POST['to'];
    $date=$_POST['date'];
    $nextDate = date('d/m/y', strtotime($date . ' +1 day'));
    $org_date = date('d/m/y', strtotime($date));
  

    // Construct SQL query
    $sql = "SELECT * FROM buses WHERE source = '$source' AND destination = '$destination'";

    // Execute SQL query
    $result = $conn->query($sql);

    // Check if there are results
    if ($result->num_rows > 0) {
        // Output data of each row
        echo "<h3 class='bus_head'>Available Buses</h3>";
        
              // Output data of each row
              while($row = $result->fetch_assoc()) {
                // Output bus details
                echo '<form action="busbook.php" method="POST">'; // Changed form action
                echo '<div class="c_bus">';
                echo '<div class="bus-details">';
                echo '<div class="bus-number">' . $row["busno"].'&nbsp;&nbsp;'.$row["bus_name"]. '</div>';
                echo '<span class="seat">' . $row["ac_type"].'&nbsp;|&nbsp;'.$row["seat"].'&nbsp;Seats'.  '&nbsp;</span>';
                echo '<span class="arri-dep arri "> ' .$row["arri_time"].'&nbsp;|&nbsp;'. $row["source"].'</span>';
                echo '<span class="date">'.$org_date. '</span>';
                echo '<span class="nxt-date">'.$nextDate. '</span>';
                echo '<span class="arri-dep dep ">'.$row["dep_time"].'&nbsp;|&nbsp;'. $row["destination"] . '</span>';
                echo '<span><p class="price">&#8377; ' . $row["price"] . '</p><span>';
                // Hidden input fields for source, destination, and date
                echo '<input type="hidden" name="source" value="' .$source. '">';
                echo '<input type="hidden" name="destination" value="' . $destination . '">';
                echo '<input type="hidden" name="date" value="' . $date . '">';
                echo '<input type="hidden" name="nextdate" value="' . $nextDate . '">';
                echo '<input type="hidden" name="ac_type" value="' . $row["ac_type"]. '">';
                echo '<input type="hidden" name="price" value="' . $row["price"]. '">';
                echo '<input type="hidden" name="arri_time" value="' . $row["arri_time"]. '">';
                echo '<input type="hidden" name="dep_time" value="' . $row["dep_time"]. '">';
                echo '<input type="hidden" name="bus_details" value="' .$row["busno"].'&nbsp;&nbsp;'.$row["bus_name"]. '">';
                
                // Book Now button
                echo '<button type="submit" class="booking-button">Book Now</button>';
                echo '</div>';
                echo '</div>';
                echo '</form>';
            }
        } else {
            echo "<p class='noresult'>No buses found for the provided source and destination.</p>";
        }

    // Close database connection
    $conn->close();
}
?>


</body>


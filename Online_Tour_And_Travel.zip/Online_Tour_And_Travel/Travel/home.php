<?php

@include 'config.php';

session_start();

if (!isset($_SESSION['user_name'])) {
    header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <!-- font -->
    <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- custom css -->
    <link rel="stylesheet" href="mystyle.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <style>
        .logindetail {
            display: inline;
            text-decoration: underline;
            border-radius: 7px;
            font-size: 1.5rem;
            position: relative;
            left: -230px;
        }

        #out {
            display: inline;
            position: relative;
            left: -70px;
            font-size: 2.5rem;
        }

        .i-logo{
            font-size: 70px;
        }
        .locate{
            margin-left: 350px;
            margin-top: 50px;
        }
    </style>
</head>

<body>

    <!-- header start -->
    <section class="header">
        <a href="login_form.php" id="out"><abbr title="Logout">⏪</abbr></a>
        <a class="logindetail logo">&nbsp;Hi,<?php echo $_SESSION['user_name'] ?>&nbsp;&nbsp;</a>
        <a href="#" class="logo"><span style="color:red;" class="gt">G</span>travel</a>
        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="about.php">about</a>
            <a href="package.php">package</a>
            <a href="MyTrips.php">MyTrips</a>

        </nav>
        <div id="menu-btn" class="fas fa-bars">☰</div>
    </section>

    <!-- header ends -->
    <!-- home section starts -->
    <section class="home">
        <div class="swiper home-slider">

            <div class="swiper-wrapper">


                <div class="swiper-slide slide" style="background:url(images/slidebus2.jpg) no-repeat">
                    <div class="content">
                    <span>explore,discover, travel</span>
                    <h3>travel around the world</h3>
                    <a href="buses.php" class="btn locate" >Search Bus</a>
                </div>


                </div>
                <div class="swiper-slide slide" style="background:url(images/slidebus1.jpg) no-repeat">
                    <div class="content">
                    <span>explore,discover, travel</span>
                    <h3>discover the new place</h3>
                    <a href="buses.php" class="btn locate">Search Bus</a>
                </div>


                </div>
                <div class="swiper-slide slide" style="background:url(images/slidebus3.jpg) no-repeat">
                    <div class="content">
                    <span>explore,discover, travel</span>
                    <h3>make your tour with the world</h3>
                    <a href="buses.php" class="btn locate">Search Bus</a>
                </div>

                </div>
            </div>
      
        </div>
        </div>
        <div class="ok swiper-button-next"></div>
        <div class="ok swiper-button-prev"></div>

        </div>

    </section>
    <!-- service section starts -->
    <section class="services">
        <h1 class="heading-title">our services</h1>

        <div class="box-container">
            <a href="package.php">
                <div class="box">
                <i class="fa-solid fa-couch i-logo"></i>
                    <h3>Comfort</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                <i class="fa-regular fa-compass i-logo"></i>
                     <h3>Tour guide</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                <i class="fa-regular fa-clock i-logo"></i>                 
                   <h3>27x7 Support</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                    <img src="images\icon4.jpeg" alt="cf">
                    <h3>Ac/Non-Ac</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                    <img src="images\icon5.png" alt="or">
                    <h3>Delux</h3>
                </div>
            </a>
            <a href="package.php">
                <div class="box">
                    <img src="images\icon6.png" alt="camp">
                    <h3>camping</h3>
                </div>
            </a>
        </div>
    </section>

    <!-- service section ends -->




    <!-- home about section starts -->

    <section class="home-about">
        <div class="image">
            <img src="images/aboutimg.jpg" alt="aboutbg">
        </div>

        <div class="content">
            <h3>about us</h3>
            <p>We Are A Passionate Team Of Travel Enthusiasts Dedicated To Providing You With The Best Travel Experiences. Our Mission Is To Help You Discover The Beauty Of The World Through Carefully Crafted Tours And Adventures.</p>
            <a href="about.php" class="btn">Read More</a>
        </div>
    </section>
    <!-- home about section ends -->




    <section class="packages">
        <h1 class="heading-title">top categories</h1>
        <div class="box-container">

            <a href="pkgforeign.php" class="btn">Historical Sites</a>
            <a href="pkgadv.php" class="btn">Adventure Destinations</a>
            <a href="pkgrel.php" class="btn">Religious Sites</a>
            <a href="pkgcruise.php" class="btn">Natural beauty</a>
            <a href="pkgcombo.php" class="btn">Combo Tour Packages</a>
            <a href="package.php" class="btn">Explore All</a>


        </div>
        <div class="load-more"><a href="package.php" class="btn">load more</a></div>
    </section>



    <!-- home packages section ends -->

    <!-- home offer section start -->
    <section class="home-offer">
        <div class="content">
            <h3>upto 50% off</h3>
            <p>Get More Benefits And Vouchers With Your Favourite Place Package </p>
        </div>
    </section>

    <!-- home offer section end -->


    <?php include 'pkgfoot.php'; ?>






    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

    <script src="script.js"></script>

</body>

</html>
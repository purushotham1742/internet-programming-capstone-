<?php

@include 'config.php';

session_start();

if (!isset($_SESSION['user_name'])) {
  header('location:login_form.php');
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MyTrips</title>
  <link rel="stylesheet" href="mystyle.css">
  <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
    .receipt {
      width: 700px;
      border: 2px solid #000;
      padding: 10px;
      margin-left: 450px;
      font-family: Arial, sans-serif;
    }

    .head {
      text-align: center;
      font-size: 20px;
      font-weight: bold;
      color: aqua;
    }

    .info {
      margin-top: 10px;
      font-size: 14px;
    }

    .item {

      font-size: 16px;

      padding: 15px;
    }

    .total {
      margin-top: 10px;
      font-size: 18px;
      font-weight: bold;
      text-align: right;
    }

    .rec {
      display: block;

      height: 200px;
    }

    .receipt {
      position: relative;
      top: 10px;
    }

    .submit {
      position: relative;
      left: 1180px;
      top: -30px;
      padding: 8px;
      font-size: 15px;
      border-radius: 10px;
    }

    h1 {
      text-align: center;
    }

    table {
      width: 80%;
      margin: 0 auto;
      border-collapse: collapse;
    }

    th,
    td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    


    *{
    /* Replace 'your_image.jpg' with the path to your image */
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
}
    

    .error {
      color: white;
      text-align: center;
      position: relative;
      top: 100px;
      left: 600px;
      background-color: red;
      width: 400px;
    }
  </style>
  <link rel="stylesheet" href="../crud_html/css/style.css">
</head>


<body style="background:url(images/bus_bg.jpeg) no-repeat; max-width:100%; max-height:100%;">

  <!-- header start -->

  <section class="header">
    <a href="login_form.php" id="out"><abbr title="Logout">⏪</abbr></a>
    <a class="logindetail logo">&nbsp;Hi,<?php echo $_SESSION['user_name'] ?>&nbsp;&nbsp;</a>
    <a href="#" class="logo"><span style="color:red;" class="gt">G</span>travel</a>
    <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="Package.php">package</a>
      <a href="MyTrips.php">MyTrips</a>

    </nav>

    <div id="menu-btn" class="fas fa-bars">☰</div>

  </section>

  <!-- header ends -->






  <br /><br />
  <h2 class="head">Check Your Booking Status....</h2><br>
  <form class="post-form" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
    <div class="form-group">

      <input type="text" class="receipt" name="sno" placeholder="Enter Your Receipt Number...." />
    </div>
    <input class="submit" type="submit" name="showbtn" value="Show" />
  </form>
  <br><br><br>

  <table>
    <tr>
      <th>Journey Details</th>
      <th>Biller Name</th>
      <th>Details</th>
      <th>Receipt No</th>
      <th>Total Amt.</th>
      <th>Status</th>
      <th>Action</th>
      <th>Receipt</th>
    </tr>
    <?php
    if (isset($_POST['showbtn'])) {

      $conn = mysqli_connect("localhost", "root", "", "travel_db") or die("Connection Faild");
      $sno_id = $_POST['sno'];
      $sql = "SELECT * FROM receipt_table WHERE receiptno = '$sno_id'";
      $result = mysqli_query($conn, $sql) or die("Query Unsuccessful");

      if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_assoc($result)) {
          $fname = $row['fname'];
          $email = $row['email'];
          $pkgname = $row['pkgname'];
          $price = $row['total'];
          $receiptno = $row['receiptno'];
          $status = $row['status'];
          $ref = $row['ref_no'];

    ?>

          <form class="post-form" action="updatedata.php" method="post">

            <tr>
            <tr>
              <td><?php echo $pkgname; ?> </td>
              <td><?php echo $fname; ?> </td>
              <td><?php echo $email; ?> </td>
              <td><?php echo $receiptno; ?> </td>

              <td><?php echo $price; ?> </td>
              <td><?php echo $status; ?> </td>
              <td>
                <a href='cancelpkg.php?id=<?php echo $row['receiptno'] ?>'>cancel</a>
              </td>
              <td>   <a href="http://localhost/myphp/MyProject/Online_Tour_And_Travel/Online_Tour_And_Travel/package/images/<?php echo $row['receiptno'] ?>.pdf" download="<?php echo $row['receiptno'] ?>.pdf"><i><i class="fa-solid fa-download"></i></i></a></td>

            </tr>
            </tr>
          
          </form>
          
    <?php
        }
      } else {
        //Product Not Available
        echo "<div class='error'> No Booking Record Found....</div>";
      }
    }
    ?>

  </table>

</body>

</html>
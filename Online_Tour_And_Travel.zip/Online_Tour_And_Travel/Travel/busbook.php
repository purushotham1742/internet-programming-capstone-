<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>


<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>book</title>

<!-- swiper link -->
<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

   <!-- font -->
    <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" >
<!-- custom css -->
<link rel="stylesheet" href="mystyle.css" >

<style>
        .logindetail{
    display: inline;
    text-decoration: underline;
    border-radius: 7px;
    font-size: 1.5rem;
    position: relative;
    left: -230px;

}
#out{
    display: inline;
    position: relative;
    left: -70px;
    font-size: 2.5rem;
}
</style>

</head>
<body>
    

<!-- header start -->
<section class="header">
    <!-- <a href="home.php" class="logo">Travel</a> -->
    <a href="login_form.php" id="out"><abbr title="Logout">⏪</abbr></a>
    <a class="logindetail logo">&nbsp;Hi,<?php echo $_SESSION['user_name'] ?>&nbsp;&nbsp;</a>
    <a href="#" class="logo"><span style="color:red;" class="gt">G</span>travel</a>
    <nav class="navbar">
        <a href="home.php">home</a>
        <a href="about.php">about</a>
        <a href="package.php">package</a>
        <a href="MyTrips.php">MyTrips</a>  
    </nav>
 <div id="menu-btn" class="fas fa-bars">☰</div>
</section>



<!-- header ends -->

<div class="heading" style="background:url(images/test.jpg) no-repeat">
    <h1>book now</h1>
</div>

<?php 
    $source = $_POST['source'];
    $destination = $_POST['destination'];
    $date = $_POST['date'];
    $nextdate = $_POST['nextdate'];
    $ac_type = $_POST['ac_type'];
    $price = $_POST['price'];
    $arri_time = $_POST['arri_time'];
    $dept_time = $_POST['dep_time'];
    $bus_details = $_POST['bus_details'];
?>
<!-- booking section starts -->
<section class="booking">
    <h1 class="heading-title">book your trip!</h1>

    <form action="buspay.php" method="post" class="book-form">
        <div class="flex">
            
            <div class="inputBox">
                <span>From :</span>
                <input type="text" value="<?php echo $source;?>" name="source" readonly>
                <input type="hidden" value="<?php echo $row['duration'];?>" name="pkg_dur" required>
                <input type="hidden" value="<?php echo $row['discription'];?>" name="pkg_dis" required>
                <input type="hidden" value="<?php echo $row['mode'];?>" name="pkg_mode" required>
                <input type="hidden" value="<?php echo $row[''];?>" name="pkg_mode" required>
                <input type="hidden" value="<?php echo $row['mode'];?>" name="pkg_mode" required>
            </div>
            <div class="inputBox">
                <span>To:</span>
                <input type="text" value="<?php echo $destination;?>" name="destination" readonly>
            </div>
            <div class="inputBox">
                <span>Date :</span>
                <input type="text" id="date" min="" value="<?php echo $date;?>" required  name="date" readonly>
            </div>
            
            <div class="inputBox">
                <span>Bus Details :</span>
                <input type="text"  name="bus_details" value="<?php echo $bus_details;?>" readonly>
            </div>
            
            <div class="inputBox">
                <span>Full Name :</span>
                <input type="text" placeholder="Enter your name"  name="name" required>
            </div>
            <div class="inputBox">
                <span>Email :</span>
                <input type="email" placeholder="Enter your email" name="email" required>
            </div>
            <div class="inputBox">
                <span>Phone :</span>
                <input type="text" placeholder="Enter your number" name="phone" pattern="[0-9]{10}" required>
            </div>
            <div>
            <input type="hidden" value="<?php echo $nextdate;?>" name="nextdate" required>
            <input type="hidden" value="<?php echo $ac_type;?>" name="ac_type" required>
            <input type="hidden" value="<?php echo $price;?>" name="price" required>
            <input type="hidden" value="<?php echo $arri_time;?>" name="arri_time" required>
            <input type="hidden" value="<?php echo $dept_time;?>" name="dep_time" required>

            </div>
        </div>

        <a href="buspay.php"><input type="submit" value="Proceed to Pay" onclick="return confirm('Make Sure Data is currect before payment...');" class="btn"></a>
    </form>


</section>


<script>
    // Get the current date in YYYY-MM-DD format
    const today = new Date();
    const year = today.getFullYear();
    let month = today.getMonth() + 1;
    let day = today.getDate();

    if (month < 10) {
      month = `0${month}`;
    }

    if (day < 10) {
      day = `0${day}`;
    }

    const currentDate = `${year}-${month}-${day}`;

    // Set the minimum date for the input element
    document.getElementById("date").min = currentDate;
  </script>

<!-- booking section ends -->



<footer>
    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"><i class="fas fa-angle-right"></i> home</a>
                <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
                <a href="Package.php"><i class="fas fa-angle-right"></i>package</a>
                <a href="book.php"><i class="fas fa-angle-right"></i>book</a>          
            </div>

            <div class="box">
                <h3>Extra links</h3>
                <a href="#"><i class="fas fa-angle-right"></i>Ask questions</a>
                <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                <a href="#"><i class="fas fa-angle-right"></i>Privacy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>            
            </div>

            <div class="box">
                <h3>Contact info</h3>
                <a href="#"><i class="fas fa-phone"></i>📞+91 123-4567-890</a>
                <a href="#"><i class="fas fa-phone"></i>📞+91 111-4567-890</a>
                <a href="#"><i class="fas fa-envelope"></i>mymail@gmail.com</a>
                <a href="#"><i class="fas fa-map"></i>Mumbai, India - 400104</a>         
            </div>

            <div class="box">
                <h3>follow us</h3>
                <a href="#"><i class="fab fa-facebook-f">facebook</i></a>
                <a href="#"><i class="fab fa-twitter">twitter</i></a>
                <a href="#"><i class="fab fa-insta">instagram</i></a>
                <a href="#"><i class="fab fa-linkedin">linkedin</i></a>
            </div>

        </div>

    </section>
</footer>







<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<script src="script.js"></script>

</body>
</html>





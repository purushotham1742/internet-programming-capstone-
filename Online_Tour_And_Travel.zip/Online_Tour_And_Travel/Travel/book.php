<?php

@include 'config.php';

session_start();

if (!isset($_SESSION['user_name'])) {
    header('location:login_form.php');
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>book</title>

    <!-- swiper link -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

    <!-- font -->
    <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- custom css -->
    <link rel="stylesheet" href="mystyle.css">

    <style>
        .logindetail {
            display: inline;
            text-decoration: underline;
            border-radius: 7px;
            font-size: 1.5rem;
            position: relative;
            left: -230px;

        }

        #out {
            display: inline;
            position: relative;
            left: -70px;
            font-size: 2.5rem;
        }
        #options{
            margin-top: 30px;
            padding: 20px;
        }
    </style>

</head>

<body>


    <!-- header start -->
    <section class="header">
        <!-- <a href="home.php" class="logo">Travel</a> -->
        <a href="login_form.php" id="out"><abbr title="Logout">⏪</abbr></a>
        <a class="logindetail logo">&nbsp;Hi,<?php echo $_SESSION['user_name'] ?>&nbsp;&nbsp;</a>
        <a href="#" class="logo"><span style="color:red;" class="gt">G</span>travel</a>
        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="about.php">about</a>
            <a href="package.php">package</a>
            <a href="MyTrips.php">MyTrips</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars">☰</div>
    </section>


    <?php
    $conn = mysqli_connect("localhost", "root", "", "travel_db") or die("Connection Faild");
    $pkg_id = $_GET['book'];
    $sql = "SELECT * FROM products WHERE id = {$pkg_id}";
    $result = mysqli_query($conn, $sql) or die("Query Unsuccessful");

    if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_assoc($result)) {

    ?>

            <!-- header ends -->

            <div class="heading" style="background:url(images/homeslide1.jpg) no-repeat">
                <h1>book now</h1>
            </div>

            <!-- booking section starts -->
            <section class="booking">
                <h1 class="heading-title">book your trip!</h1>

                <form action="payment.php" method="post" class="book-form">
                    <div class="flex">

                        <div class="inputBox">
                            <span>Package Name :</span>
                            <input type="text" value="<?php echo $row['name']; ?>" name="pkg_name" readonly>
                            <input type="hidden" value="<?php echo $row['duration']; ?>" name="pkg_dur" required>
                            <input type="hidden" value="<?php echo $row['discription']; ?>" name="pkg_dis" required>
                            <input type="hidden" value="<?php echo $row['mode']; ?>" name="pkg_mode" required>
                        </div>
                        <div class="inputBox">
                            <span>Per Guest(in Rs.):</span>
                            <input type="text" value="<?php echo $row['price']; ?>" name="pkg_price" readonly>
                        </div>
                        <div class="inputBox">
                            <span>Full Name :</span>
                            <input type="text" placeholder="Enter your name" name="name" required>
                        </div>
                        <div class="inputBox">
                            <span>Email :</span>
                            <input type="email" placeholder="Enter your email" name="email" required>
                        </div>
                        <div class="inputBox">
                            <span>Phone :</span>
                            <input type="text" placeholder="Enter your number" name="phone" pattern="[0-9]{10}" required>
                        </div>
                        <div class="inputBox">
                            <span>Address :</span>
                            <input type="text" placeholder="Enter your address" name="address" required>
                        </div>
                        <div class="inputBox">
                            <span>Origin :</span>
                            <input type="text" placeholder="Enter origin to provide pick-up service" name="location" required>
                        </div>

                        <div class="inputBox">
                            <span>No of Guests(Free for child below 5yr) :</span>
                            <input type="number" placeholder="Number of Guests" name="guests" required>
                        </div>
                        <div class="inputBox">
                            <span>Start Date :</span>
                            <input type="date" id="date" min="" required name="arrivals">
                        </div>
                        <div class="inputBox">
                            <span>Duration :</span>
                            <input type="text" name="leaving" value="<?php echo $row['duration']; ?>" readonly>
                        </div>
                        <div class="inputBox">
                            <span>Bus Type :</span>
                            <select id="options" name="option">
                                <option value="Single Deck">Single Deck Bus</option>
                                <option value="Double dacker">Double Decker Bus</option>
                                <option value="Luxury">Luxury Bus</option>
                                <option value="Electric">Electric Bus</option>
                                <option value="Vanity">Vanity Van</option>
                            </select>
                        </div>
                    </div>

                    <a href="payment.php"><input type="submit" value="Proceed to Pay" onclick="return confirm('Make Sure Data is currect before payment...');" class="btn"></a>
                </form>


            </section>


            <script>
                // Get the current date in YYYY-MM-DD format
                const today = new Date();
                const year = today.getFullYear();
                let month = today.getMonth() + 1;
                let day = today.getDate();

                if (month < 10) {
                    month = `0${month}`;
                }

                if (day < 10) {
                    day = `0${day}`;
                }

                const currentDate = `${year}-${month}-${day}`;

                // Set the minimum date for the input element
                document.getElementById("date").min = currentDate;
            </script>
    <?php
        }
    }
    ?>
    <!-- booking section ends -->



    <footer>
        <section class="footer">

            <div class="box-container">

                <div class="box">
                    <h3>Quick links</h3>
                    <a href="home.php"><i class="fas fa-angle-right"></i> home</a>
                    <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
                    <a href="Package.php"><i class="fas fa-angle-right"></i>package</a>
                    <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
                </div>

                <div class="box">
                    <h3>Extra links</h3>
                    <a href="#"><i class="fas fa-angle-right"></i>Ask questions</a>
                    <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                    <a href="#"><i class="fas fa-angle-right"></i>Privacy Policy</a>
                    <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
                </div>

                <div class="box">
                    <h3>Contact info</h3>
                    <a href="#"><i class="fas fa-phone"></i>📞+91 123-4567-890</a>
                    <a href="#"><i class="fas fa-phone"></i>📞+91 111-4567-890</a>
                    <a href="#"><i class="fas fa-envelope"></i>mymail@gmail.com</a>
                    <a href="#"><i class="fas fa-map"></i>Mumbai, India - 400104</a>
                </div>

                <div class="box">
                    <h3>follow us</h3>
                    <a href="#"><i class="fab fa-facebook-f">facebook</i></a>
                    <a href="#"><i class="fab fa-twitter">twitter</i></a>
                    <a href="#"><i class="fab fa-insta">instagram</i></a>
                    <a href="#"><i class="fab fa-linkedin">linkedin</i></a>
                </div>

            </div>

        </section>
    </footer>







    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

    <script src="script.js"></script>

</body>

</html>
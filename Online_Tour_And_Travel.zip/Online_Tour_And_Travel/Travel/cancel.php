<?php 


$receiptno= $_POST['receiptno'];

$conn = new mysqli('localhost','root','','travel_db');
if($conn->connect_error){
    die('Connection failed :' .$connect_error);
}else{
    $stmt= $conn->prepare("insert into receipt_table(fname, pkgname, email, total, receiptno) values(?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $fname, $pkgname, $email, $total, $receiptno);
    $stmt->execute();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>hii</p>
</body>
</html>
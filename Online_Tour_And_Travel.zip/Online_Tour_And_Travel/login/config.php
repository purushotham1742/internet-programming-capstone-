<?php

$conn = mysqli_connect('localhost','root','','travel_db');

?>
<?php include 'admin_page.php'; ?>
<div id="main-content">
    <br/><br/>
    <h2>All Booking Records</h2>
    <?php
    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sql = "SELECT * FROM user_data";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");
    
    if(mysqli_num_rows($result)>0){

    ?>
    <table cellpadding="7px">
        <thead>
        <th>S No.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th> 
        <th>Action</th>
        </thead>
        <tbody>
            <?php 
            while($row = mysqli_fetch_assoc($result)){
            ?>
            <tr>
                <td><?php echo $row['sno'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['password'] ?></td>
                <td><?php echo $row['user_type'] ?></td>
                <td>
                    <a href='makeAdmin.php?aid=<?php echo $row['sno'] ?>'>Admin</a>
                    <a href='makeAdmin.php?uid=<?php echo $row['sno'] ?>'>User</a>
                    <a href='makeAdmin.php?did=<?php echo $row['sno'] ?>'>Delete</a>
                </td>
            </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
    <?php }
    ?>
</div>
</div>
</body>
</html>
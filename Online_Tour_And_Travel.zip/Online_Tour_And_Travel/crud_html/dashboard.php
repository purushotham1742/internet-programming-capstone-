<?php include 'admin_page.php'; ?>

<?php

$conn = mysqli_connect("localhost", "root", "", "travel_db") or die("Connection Faild");
$query1 = "SELECT COUNT(*) AS count FROM book_table";
$result1 = mysqli_query($conn, $query1) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result1)) {

  $output = $row['count'];
}


$query2 = "SELECT COUNT(*) AS count FROM contact_table";
$result2 = mysqli_query($conn, $query2) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result2)) {

  $contact = $row['count'];
}

$query3 = "SELECT COUNT(*) AS count FROM products";
$result3 = mysqli_query($conn, $query3) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result3)) {

  $packages = $row['count'];
}

$query4 = "SELECT COUNT(*) AS count FROM user_data";
$result4 = mysqli_query($conn, $query4) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result4)) {

  $users = $row['count'];
}

$query5 = "SELECT COUNT(*) AS count FROM receipt_table WHERE status='requested'";
$result5 = mysqli_query($conn, $query5) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result5)) {

  $cancel = $row['count'];
}
$query6 = "SELECT COUNT(*) AS count FROM buses";
$result6 = mysqli_query($conn, $query6) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result6)) {

  $buses = $row['count'];
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/d8cfbe84b9.js" crossorigin="anonymous"></script>
    <!-- CSS -->

 
      <style>
    #main-content h3{
        padding-left: 1rem;
        margin-bottom: 0;
        text-transform: uppercase;
    }

    #status, #user, #admin{
        display: flex;
        flex-wrap: wrap;
    }

    .info-box{
        padding: 0.3rem 1rem;
        border-left: 4px solid;
        margin: 1rem;
        flex-basis: 45%;
        border-radius: 5px;
        box-shadow: 7px 7px 4px rgba(0, 0, 0, 0.25);
        background-color: white;
    }

    .heading{
        display: flex;
        justify-content: space-between;
    }
    .heading h5{
        color: white;
        text-align: center;
        padding: 0.5rem 1rem;
        flex-basis: 70%;
        border-radius: 0px;
        margin: 0.5rem 0;
    }

    .info-box p{
        margin: 0;
    }

    .info-content{
        margin-bottom: 1rem;
    }

    .info-content .num{
        font-size: 1.5rem;
    }

    .info-box a{
        display: block;
        text-align: right;
        text-decoration: none;
        font-weight: bold;
    }
    /* START-hardcoding */
    #Booking{
        border-color: #3e93d9;
    }

    #Booking h5{
        background-color: #3e93d9;
    }
    #Booking a{
        color: #3e93d9;
    }

    #Earning {
        border-color: #23bf29;
    }

    #Earning a{
        color: #23bf29;
    }

    #Bus {
        border-color: #009688;
    }

    #Bus h5{
        background-color: #009688;
    }

    #Bus a{
        color: #009688;
    }

    #Route{
        border-color: #f44336;
    }

    #Route h5{
        background-color: #f44336;
    }

    #Route a{
        color: #f44336;
    }

    #Seat{
        border-color: #A66314;
    }

    #Seat h5{
        background-color: #A66314;
    }

    #Seat a{
        color: #A66314;
    }

    #Customer{
        border-color: #2D2B28;
    }

    #Customer h5{
        background-color: #2D2B28;
    }

    #Customer a{
        color: #2D2B28;
    }

    #Admin{
        border-color: #607d8b;
    }

    #Admin h5{
        background-color: #607d8b;
    }

    #Earning h5{
        background-color: #23bf29;
    }

    #Admin a{
        color: #607d8b;
    }
    /* END-hardcoding */


    #admin .info-box{
        text-align: center;
        padding: 1rem 0;
        border: none;
    }

    #admin h4{
        margin: 0.5rem 0;
    }

    #admin img{
        border-radius: 50%;
    }


    @media only screen and (min-width:1000px){
        #main-content{
            flex-grow: 1;
        }

        .info-box{
            flex-basis: 20%;
        }

        #admin .info-box{
            flex-basis: 15%;
        }
    }

    #dashboard{
      margin-left: 120px;
    }
</style>
    
</head>
<body>
    <!-- Requiring the admin header files -->

<br><br><br>
            <section id="dashboard">
                
                <div id="status">
                    <div id="Booking" class="info-box status-item">
                        <div class="heading">
                        <a href="index.php"><h5>Bookings&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5></a>
                            <div class="info">
                                <i class="fas fa-ticket-alt"></i>
                            </div>
                        </div>
                        <div class="info-content">
                            <p>Total Bookings</p>
                            <p class="num" >
                                <?php echo $output; ?>
                            </p>
                        </div>
                        <a href="index.php">View More <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div id="Bus" class="info-box status-item">
                        <div class="heading">
                        <a href="bus_add.php"><h5>Buses&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5></a>
                            <div class="info">
                                <i class="fas fa-bus"></i>
                            </div>
                        </div>
                        <div class="info-content">
                            <p>Total Buses</p>
                            <p class="num" >
                                <?php echo $buses; ?>
                            </p>
                        </div>
                        <a href="bus_add.php">View More <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div id="Route" class="info-box status-item">
                        <div class="heading">
                        <a href="add.php"><h5>Packages&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5></a>
                            <div class="info">
                                <i class="fas fa-road"></i>
                            </div>
                        </div>
                        <div class="info-content">
                            <p>Offering Packages</p>
                            <p class="num" >
                                <?php echo $packages; ?>
                            </p>
                        </div>
                        <a href="add.php">View More <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div id="Seat" class="info-box status-item">
                        <div class="heading">
                        <a href="manageUser.php"><h5>Users&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5></a>
                            <div class="info">
                                <i class="fas fa-th"></i>
                            </div>
                        </div>
                        <div class="info-content">
                            <p>Total Users</p>
                            <p class="num" >
                                <?php echo $users; ?>
                            </p>
                        </div>
                        <a href="manageUser.php">View More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <!-- <h3>User</h3> -->
                <div id="user">
                    <div id="Customer" class="info-box user-item">
                        <div class="heading">
                        <a href="contact_data.php"><h5>Quries&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5></a>
                            <div class="info">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="info-content">
                            <p>Total Queries</p>
                            <p class="num" >
                                <?php echo $contact; ?>
                            </p>
                        </div>
                        <a href="contact_data.php">View More <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div id="Admin" class="info-box user-item">
                        <div class="heading">
                        <a href="status.php"><h5>Cancel&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5></a>
                            <div class="info">
                                <i class="fas fa-user-lock"></i>
                            </div>
                        </div>
                        <div class="info-content">
                            <p>Cancel Request</p>
                            <p class="num" >
                                <?php echo $cancel; ?>
                            </p>
                        </div>
                        <a href="status.php">View More <i class="fas fa-arrow-right"></i></a>
                    </div>



                </div>

            </section>
                <footer>
                    <p>
                        </p>
                </footer>
        </div>
    </main>
</body>
</html>
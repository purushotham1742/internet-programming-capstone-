<?php include 'admin_page.php'; ?>

<?php

$conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");

if(isset($_POST['add_bus'])){
    $bus_src = $_POST['source'];
    $bus_no = $_POST['busno'];
    $bus_name = $_POST['bus_name'];
    $bus_des = $_POST['destination'];
    $bus_seat = $_POST['seat'];
   $bus_ar = $_POST['arrival_time'];
   $bus_dep = $_POST['departure_time'];
   $bus_route = $_POST['via_route'];
   $bus_day = $_POST['running_days'];
   $bus_price = $_POST['price'];
   $bus_ac = $_POST['ac_non_ac'];

   $insert_query = mysqli_query($conn, "INSERT INTO `buses`(busno,bus_name, source, destination,seat,arri_time,dep_time,via,run_days,price,ac_type) VALUES('$bus_no', '$bus_name','$bus_src', '$bus_des','$bus_seat','$bus_ar','$bus_dep','$bus_route','$bus_day','$bus_price','$bus_ac')") or die('query failed');

};

?>

<!DOCTYPE html>
<html lang="en">
<title>Add Bus</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 900px;
            margin-left: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            
        }
        form {
            display: grid;
           
        }
        .form-group {
            display: grid;
            gap: 10px;
        }
        .form-group label {
        
            padding-right: 10px;
            line-height: 30px;
        }
        .form-group input, .form-group select {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group input[type="time"] {
            width: calc(50% - 5px);
        }
        .form-group select {
            width: 80%;
        }
        .form-row {
            display: flex;
            gap: 20px;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            justify-self: center;
        }
        button:hover {
            background-color: #0056b3;
        }
        .in{
    width: 150px; /* Set the width */
    height: 30px; /* Set the height */
    padding: 5px; /* Add some padding for better appearance */
    box-sizing: border-box; /* Include padding and border in the element's total width and height */
    /* Additional styling (optional) */
    border: 1px solid #ccc; /* Add a border for better visibility */
    border-radius: 4px; /* Add some border-radius for rounded corners */
  }

.bus_name{
    margin-left: 250px;
    margin-top: -70px;
}

.bus-data{
    margin-left: 200px;
}

table {
    
    border-collapse: collapse;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    font-family: Arial, sans-serif;
  }

  /* Table header */
  th {
    background-color: #4CAF50; /* Green background */
    color: white;
    padding: 12px;
    text-align: left;
  }

  /* Table body */
  td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd; /* Light gray bottom border */
    transition: background-color 0.3s ease; /* Smooth transition on hover */
  }

  /* Alternate row background color */
  tr:nth-child(even) {
    background-color: #f2f2f2; /* Lighter gray background for even rows */
  }

  /* Hover effect */
  tr:hover td {
    background-color: #c3c3c3; /* Light gray background on hover */
  }
    </style>
</head>
<body>
<br><br><br><br><br>
    <div class="container">
        
        <h1>Admin - Add Bus Details</h1>
        <form action="" method="POST">
                    <div class="form-group">
                        <label for="busno">Bus Number:</label>
                        <input type="text" class="in" name="busno" id="busno" required>
                    </div>
                    <div class="form-group bus_name">
                        <label for="bus_name"  >Agency Name</label>
                        <input type="text" class="in" name="bus_name"  required>
                    </div><br><br>
            <div class="form-row">
                <div class="form-group">
                    <label for="source">Source:</label>
                    <input type="text" name="source" id="source" required>
                </div>
                <div class="form-group">
                    <label for="destination">Destination:</label>
                    <input type="text" name="destination" id="destination" required>
                </div>
                <div class="form-group">
                    <label for="seat">Seats:</label>
                    <input type="number" name="seat" id="seat" required>
                </div>
            </div><br><br>

            <div class="form-row">
                <div class="form-group">
                    <label for="departure_time">Departure Time:</label>
                    <input type="time" name="departure_time" id="departure_time" required>
                </div>
                <div class="form-group">
                    <label for="arrival_time">Arrival Time:</label>
                    <input type="time" name="arrival_time" id="arrival_time" required>
                </div>
                <div class="form-group">
                <label for="via_route">Via Route:</label>
                <input type="text" name="via_route" id="via_route">
                </div>
            </div><br><br>


            <div class="form-row">
            <div class="form-group">
                <label for="running_days">Running Days:</label>
                <input type="text" name="running_days" id="running_days" placeholder="E.g., Mon, Wed, Fri">
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" name="price" id="price" min="0" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="ac_non_ac">AC/Non-AC:</label>
                <select name="ac_non_ac" id="ac_non_ac">
                    <option value="AC">AC</option>
                    <option value="Non-AC">Non-AC</option>
                </select>
            </div>
            </div><br>
            <button type="submit" name="add_bus">Add Bus</button>
        </form>
    </div>

<br><br><br><br><br>
    
<section class="bus-data">

<table>

   <thead>
      <th>Bus Number</th>
      <th>Agency name</th>
      <th>Source</th>
      <th>Destination</th>
      <th>No of Seats</th>
      <th>Routes</th>
      <th>Running Days</th>
      <th>Fare</th>
      <th>Type</th>
      <th>Action</th>
   </thead>

   <tbody>
      <?php
      
         $select_bus = mysqli_query($conn, "SELECT * FROM `buses`");
         if(mysqli_num_rows($select_bus) > 0){
            while($row = mysqli_fetch_assoc($select_bus)){
      ?>

      <tr>
         <td><?php echo $row['busno']; ?></td>
         <td><?php echo $row['bus_name']; ?></td>
         <td><?php echo $row['source'].' At ' .$row['arri_time']; ?></td>
         <td><?php echo $row['destination'].' At '.$row['dep_time']; ?></td>
         <td><?php echo $row['seat']; ?></td>
         <td><?php echo $row['via']; ?></td>
         <td><?php echo $row['run_days']; ?></td>
         <td><?php echo $row['price']; ?>/-</td>
         <td><?php echo $row['ac_type']; ?></td>
         <td>
            <a href="add.php?bussrno=<?php echo $row['srno']; ?>" class="delete-btn" onclick="return confirm('are your sure you want to delete this?');"> <i class="fas fa-trash"></i> </a>
            <!-- <a href="add.php?bussrno=<?php echo $row['srno']; ?>" class="option-btn"> <i class="fas fa-edit"></i> update </a> -->
         </td>
      </tr>
      

      <?php
         };    
         }else{
            echo "<div class='empty'>no product added</div>";
         };
      ?>
   </tbody>
</table>
<br><br><br><br>
</section>
<br><br><br><br>
</body>
</html>



<?php include 'admin_page.php'; ?>
<div id="main-content">
    <br/><br/>
    <h2>All Contact Requests</h2>
    <?php
    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sql = "SELECT * FROM contact_table";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");
    
    if(mysqli_num_rows($result)>0){

    ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Grid</title>
    <style>
        /* Create a grid container */
        .message-container {
            /* display: grid;
            grid-template-columns: 1fr; 
            gap: 10px; 
        */
        display: inline-block;
    height: 200px;
    width: 350px;
    padding: 20px;
    margin: 20px;
    padding-bottom: 10px;
    border: 1px solid black;
    border-radius: 10px;
    background-color: #fc466b;

        }

        /* Style for each message */
        .message {
            background-color:#90e0ef;
            padding: 10px;
            border-radius: 10px;
            height: 220px;
            width: 370px;
        }

        /* Style for sender */
        .sender {
            font-weight: bold;
        }
    </style>
</head>
<body>
<?php 
            while($row = mysqli_fetch_assoc($result)){
            ?>
    <div class="message-container">
        <!-- Message 1 -->
        <div class="message">
            <span class="sender">Name: <?php echo $row['fname']?></span><br>
            <span class="num"><b>Mo. No: </b><?php echo $row['number']?></span><br>
            <span class="email"><b>Email: </b><?php echo $row['email']?></span><br><br>
            <span class="content"><?php echo $row['msg']?></span>
        </div>

        <!-- Add more messages as needed -->
    </div>

    <?php
            }
            ?>
    <?php }
    ?>

</body>
</html>



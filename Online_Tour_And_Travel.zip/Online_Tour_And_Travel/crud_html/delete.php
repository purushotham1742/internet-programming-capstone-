<?php include 'admin_page.php'; 

if(isset($_POST['deletebtn'])){

    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $s_no = $_POST['sno'];
    $sql = "DELETE FROM book_table WHERE sno={$s_no}";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");
    header("Location: http://localhost/myphp/MyProject/Online_Tour_And_Travel/Online_Tour_And_Travel/crud_html/index.php");
    
    mysqli_close($conn);
    
}

?>


<div id="main-content">
<br/><br/>
    <h2>Delete Record</h2>
    <form class="post-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <div class="form-group">
            <label>S no.</label>
            <input type="number" name="sno" />
        </div>
        <input class="submit" type="submit" name="deletebtn" value="Delete" />
    </form>
</div>
</div>
</body>
</html>

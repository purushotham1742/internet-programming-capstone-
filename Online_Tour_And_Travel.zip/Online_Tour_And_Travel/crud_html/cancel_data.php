<?php 
$s_no = $_GET['id'];

$conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sql = "DELETE FROM receipt_table WHERE sno={$s_no}";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");
header("Location: http://localhost/myphp/MyProject/Online_Tour_And_Travel/Online_Tour_And_Travel/crud_html/status.php");

mysqli_close($conn);
?>
<?php 

$b_name = $_POST['name'];
$b_email = $_POST['email'];
$b_phone = $_POST['phone'];
$b_address = $_POST['address'];
$b_location = $_POST['location'];
$b_guests = $_POST['guests'];
$b_arrivals = $_POST['arrivals'];
$b_leaving = $_POST['leaving'];


$conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Failed");

$sql = "INSERT INTO book_table(name,email,phone,address,location,guests,arrivals,leaving) VALUES ('{$b_name}','{$b_email}','{$b_phone}','{$b_address}','{$b_location}','{$b_guests}','{$b_arrivals}','{$b_leaving}')";
$result = mysqli_query($conn, $sql) or die("Query Successful.");
header("Location: http://localhost/myphp/crud_html/index.php");
mysqli_close($conn);

?>